**********************
Numarray compatibility
**********************

The numarray module was removed in NumPy 1.9.0.
