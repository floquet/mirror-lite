***************
NumPy internals
***************

.. toctree::

   internals.code-explanations

.. automodule:: numpy.doc.internals
