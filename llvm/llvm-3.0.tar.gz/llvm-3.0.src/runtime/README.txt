This directory contains the various runtime libraries used by components of 
the LLVM compiler.  For example, the automatic pool allocation transformation
inserts calls to an external pool allocator library.  This runtime library is
an example of the type of library that lives in these directories.
