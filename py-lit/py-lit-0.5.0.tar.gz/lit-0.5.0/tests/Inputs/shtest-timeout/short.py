# RUN: %{python} %s
from __future__ import print_function

import sys

print("short program")
