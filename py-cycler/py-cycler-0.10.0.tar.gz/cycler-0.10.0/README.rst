cycler: composable cycles
=========================

Docs: http://matplotlib.org/cycler/
