./qrdemo_gpu3 A.mtx 6 > o_metis_nogpu
