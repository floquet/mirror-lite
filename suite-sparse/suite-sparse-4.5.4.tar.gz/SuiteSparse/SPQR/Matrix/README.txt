Test matrices for the programs in Demo and Tcov directories.

Timothy A. Davis, http://www.suitesparse.com
