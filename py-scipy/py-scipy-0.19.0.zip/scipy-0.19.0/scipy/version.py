
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.19.0'
version = '0.19.0'
full_version = '0.19.0'
git_revision = '29dbc361056df93fe659dcb7362fa2c0e647a14b'
release = True

if not release:
    version = full_version
