static inline void ANNOTATE_BENIGN_RACE_SIZED(const void *mem,size_t len,const char *desc) {}
#define ANNOTATE_BENIGN_RACE_SIZED ANNOTATE_BENIGN_RACE_SIZED

