============
 git-review
============

``git-review`` is a tool that helps submitting git branches to gerrit
for review.

.. toctree::
   :maxdepth: 2

   installation
   usage
   developing


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

