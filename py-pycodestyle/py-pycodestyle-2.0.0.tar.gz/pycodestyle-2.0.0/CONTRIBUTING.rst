Contributing to ``pycodestyle``
===============================

Please see the `developer notes <https://pycodestyle.readthedocs.io/en/latest/developer.html>`_
