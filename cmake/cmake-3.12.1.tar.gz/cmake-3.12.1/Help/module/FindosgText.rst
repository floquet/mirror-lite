.. cmake-module:: ../../Modules/FindosgText.cmake
